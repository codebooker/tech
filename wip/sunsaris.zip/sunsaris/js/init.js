(function($){
  $(function(){

    $('.button-collapse').sideNav({draggable: true});

  }); // end of document ready
})(jQuery); // end of jQuery name space